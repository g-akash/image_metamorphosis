There was a small inconsisteny. The features are being read as horizontal coordinate first and vertical as second. while the image pixel access is reverse. I have handled that in the distort function. 

I have submitted 3 entries for extra credit. These are ee. tower, pisa_tower. The values of a,b,p used are default given values.